from pathlib import Path

_LOCAL_DIR = Path(__file__).parent.parent / "data"
_REMOTE_DIR_GITHUB = "https://github.com/Zaf4/datasets/raw/main/feather/"
_EXTENSION = ".feather"
